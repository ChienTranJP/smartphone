"# smartphone" 
